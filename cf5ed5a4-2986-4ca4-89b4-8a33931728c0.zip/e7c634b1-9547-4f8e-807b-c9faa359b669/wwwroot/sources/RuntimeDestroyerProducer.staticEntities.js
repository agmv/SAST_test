﻿export var staticEntities = {};


