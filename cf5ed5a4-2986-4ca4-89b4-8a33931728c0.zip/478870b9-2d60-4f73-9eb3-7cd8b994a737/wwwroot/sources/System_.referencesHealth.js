﻿export default [];



